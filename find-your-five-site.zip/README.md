# Find Your Five — CS2 Community Hub

This is the first mobile-first prototype based on the supplied presentation.

## Included
- Find Players search
- Premier / role / nationality / language filters
- Player cards and profile preview
- Recent-form visualization
- Community feed
- Focused invite modal
- Responsive layout for iPhone and desktop

## Important
This version is a frontend prototype. Real Steam login, live CS2 statistics, database accounts, messaging and persistent party rooms need a backend and API integration.

## Fastest way to publish from iPhone
1. Create a GitHub account.
2. Create a new public repository, e.g. `find-your-five`.
3. Upload `index.html` to the repository.
4. GitHub: Settings → Pages → Deploy from branch → `main` / root.
5. Open the generated Pages address.

For a custom domain, connect the domain later through GitHub Pages or a hosting provider.
